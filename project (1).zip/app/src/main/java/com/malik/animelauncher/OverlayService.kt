package com.malik.animelauncher

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.malik.animelauncher.STOP"
        private const val CHANNEL_ID = "overlay"
        private val COMMANDS = listOf(
            "День" to "/time set day",
            "Ночь" to "/time set night",
            "Ясная погода" to "/weather clear",
            "Креатив" to "/gamemode creative",
            "Выживание" to "/gamemode survival",
            "Часы" to "/give @s clock",
            "Подняться вверх" to "/tp @s ~ ~10 ~"
        )
        private val CHECKS = listOf(
            "Железо", "Алмазы", "Портал в Незер",
            "Эндер-жемчуг", "Зачарование", "Убить дракона"
        )
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var panel: View? = null
    private var card: View? = null
    private val animators = mutableListOf<ObjectAnimator>()

    private var timerEnd = 0L
    private var timerText: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (timerEnd == 0L) return
            val left = timerEnd - SystemClock.elapsedRealtime()
            if (left <= 0) {
                timerEnd = 0L
                timerText?.text = "Время! 🌸"
                Toast.makeText(this@OverlayService, "⏰ Таймер закончился", Toast.LENGTH_LONG).show()
                return
            }
            timerText?.text = formatLeft()
            handler.postDelayed(this, 300)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("overlay", MODE_PRIVATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) showBubble()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Меню поверх игры", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.petal)
            .setContentTitle("桜 Меню активно")
            .setContentText("Сакура на экране открывает меню")
            .addAction(0, "Выключить", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------- helpers ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun colorText() = 0xFF5B3A8C.toInt()

    private fun rowParams(bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, 0, 0, bottom) }

    private fun pop(v: View) {
        v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun copy(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
        Toast.makeText(this, "Скопировано: $text", Toast.LENGTH_SHORT).show()
    }

    private fun formatLeft(): String {
        if (timerEnd == 0L) return "00:00"
        val left = timerEnd - SystemClock.elapsedRealtime()
        val s = ((left + 999) / 1000).toInt().coerceAtLeast(0)
        return String.format("%02d:%02d", s / 60, s % 60)
    }

    // ---------------- bubble ----------------

    private fun showBubble() {
        val size = dp(60)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }

        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_sakura)
            setBackgroundResource(R.drawable.bubble_bg)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        wm.updateViewLayout(view, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                }
            }
            true
        }

        wm.addView(v, lp)
        bubble = v

        animators.add(
            ObjectAnimator.ofFloat(v, View.ROTATION, 0f, 360f).apply {
                duration = 18000
                repeatCount = ObjectAnimator.INFINITE
                interpolator = LinearInterpolator()
                start()
            }
        )
        animators.add(
            ObjectAnimator.ofPropertyValuesHolder(
                v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.9f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.9f)
            ).apply {
                duration = 900
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
                start()
            }
        )
    }

    // ---------------- panel ----------------

    private fun togglePanel() {
        if (panel == null) openPanel() else closePanel()
    }

    private fun openPanel() {
        val screenW = resources.displayMetrics.widthPixels
        val width = min(dp(340), screenW - dp(16))

        val outer = FrameLayout(this).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val c = buildCard()
        outer.addView(
            c,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val lp = WindowManager.LayoutParams(
            width + dp(24), ViewGroup.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm.addView(outer, lp)
        panel = outer
        card = c

        c.scaleX = 0.7f
        c.scaleY = 0.7f
        c.alpha = 0f
        c.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(280).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun closePanel() {
        val p = panel ?: return
        val c = card
        panel = null
        card = null
        timerText = null
        if (c == null) {
            try { wm.removeView(p) } catch (e: Exception) { }
            return
        }
        c.animate().scaleX(0.8f).scaleY(0.8f).alpha(0f).setDuration(180).withEndAction {
            try { wm.removeView(p) } catch (e: Exception) { }
        }.start()
    }

    private fun buildCard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.panel_bg)
            setPadding(dp(14), dp(12), dp(14), dp(14))
            elevation = dp(6).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(this).apply {
                text = "桜 Меню"
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(colorText())
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(colorText())
            setPadding(dp(10), 0, dp(4), 0)
            setOnClickListener { closePanel() }
        })
        root.addView(header)

        val names = listOf("Команды", "Таймер", "Список")
        val builders = listOf({ commandsView() }, { timerView() }, { checklistView() })
        val content = FrameLayout(this)
        val tabViews = mutableListOf<TextView>()

        fun select(i: Int) {
            timerText = null
            tabViews.forEachIndexed { idx, t ->
                if (idx == i) {
                    t.setBackgroundResource(R.drawable.btn_primary)
                    t.setTextColor(0xFFFFFFFF.toInt())
                    t.setTypeface(null, Typeface.BOLD)
                } else {
                    t.setBackgroundResource(R.drawable.btn_secondary)
                    t.setTextColor(colorText())
                    t.setTypeface(null, Typeface.NORMAL)
                }
            }
            content.removeAllViews()
            val v = builders[i]()
            content.addView(v)
            v.alpha = 0f
            v.translationY = dp(14).toFloat()
            v.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEachIndexed { i, name ->
            val t = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                setOnClickListener { select(i) }
            }
            tabViews.add(t)
            tabs.addView(
                t,
                LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
            )
        }

        root.addView(
            tabs,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )
        root.addView(
            content,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170))
                .apply { topMargin = dp(10) }
        )
        select(0)
        return root
    }

    // ---------------- tabs ----------------

    private fun commandsView(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        COMMANDS.forEach { (label, cmd) ->
            col.addView(
                TextView(this).apply {
                    text = "$label\n$cmd"
                    textSize = 13f
                    setTextColor(colorText())
                    setBackgroundResource(R.drawable.btn_secondary)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    setOnClickListener {
                        copy(cmd)
                        pop(this)
                    }
                },
                rowParams(dp(6))
            )
        }
        sv.addView(col)
        return sv
    }

    private fun chipButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setBackgroundResource(R.drawable.btn_secondary)
            setOnClickListener {
                onClick()
                pop(this)
            }
        }

    private fun timerView(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val tv = TextView(this).apply {
            textSize = 44f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(colorText())
            text = formatLeft()
        }
        timerText = tv
        col.addView(tv)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        listOf(1, 5, 10).forEach { m ->
            row.addView(
                chipButton("$m мин") { startTimer(m) },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
            )
        }
        row.addView(
            chipButton("Стоп") { stopTimer() },
            LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
        )
        col.addView(
            row,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(12) }
        )
        return col
    }

    private fun startTimer(minutes: Int) {
        timerEnd = SystemClock.elapsedRealtime() + minutes * 60_000L
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun stopTimer() {
        timerEnd = 0L
        handler.removeCallbacks(tick)
        timerText?.text = "00:00"
    }

    private fun checklistView(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        CHECKS.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                textSize = 15f
                setTextColor(colorText())
                setBackgroundResource(R.drawable.btn_secondary)
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            fun render() {
                val done = prefs.getBoolean("c$i", false)
                tv.text = (if (done) "☑  " else "☐  ") + name
                tv.paintFlags = if (done) {
                    tv.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                } else {
                    tv.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
            }
            render()
            tv.setOnClickListener {
                prefs.edit().putBoolean("c$i", !prefs.getBoolean("c$i", false)).apply()
                render()
                pop(tv)
            }
            col.addView(tv, rowParams(dp(6)))
        }
        sv.addView(col)
        return sv
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        animators.forEach { it.cancel() }
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null
        bubble = null
        super.onDestroy()
    }
}
