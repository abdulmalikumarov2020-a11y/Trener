package com.malik.animelauncher

import android.Manifest
import android.animation.ObjectAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private val minecraft = "com.mojang.minecraftpe"

    private val pickPack =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) openInMinecraft(uri)
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<View>(R.id.btnPlay).setOnClickListener { playMinecraft() }
        findViewById<View>(R.id.btnOverlay).setOnClickListener { startOverlayAndPlay() }
        findViewById<View>(R.id.btnStopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            toast("Меню выключено")
        }
        findViewById<View>(R.id.btnCosmetics).setOnClickListener { installBundledPack() }
        findViewById<View>(R.id.btnImport).setOnClickListener { pickPack.launch(arrayOf("*/*")) }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        startPetals()
    }

    private fun playMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage(minecraft)
        if (intent == null) {
            toast("Minecraft не найден на телефоне")
        } else {
            startActivity(intent)
        }
    }

    private fun startOverlayAndPlay() {
        val launch = packageManager.getLaunchIntentForPackage(minecraft)
        if (launch == null) {
            toast("Minecraft не найден на телефоне")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Включи «Поверх других приложений» для этого лаунчера и вернись назад")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        startActivity(launch)
    }

    private fun installBundledPack() {
        try {
            val dir = File(cacheDir, "packs").apply { mkdirs() }
            val file = File(dir, "Cosmetics.mcpack")
            assets.open("Cosmetics.mcpack").use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            openInMinecraft(uri)
        } catch (e: Exception) {
            toast("Не удалось открыть пак: ${e.message}")
        }
    }

    private fun openInMinecraft(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(minecraft)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Minecraft не найден или не принимает файл")
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun startPetals() {
        val layer = findViewById<FrameLayout>(R.id.petalLayer)
        layer.post {
            val w = layer.width
            val h = layer.height.toFloat()
            val density = resources.displayMetrics.density
            repeat(16) {
                val size = (Random.nextInt(14, 30) * density).toInt()
                val petal = ImageView(this).apply {
                    setImageResource(R.drawable.petal)
                    layoutParams = FrameLayout.LayoutParams(size, size)
                    alpha = Random.nextFloat() * 0.4f + 0.5f
                    x = Random.nextInt(0, maxOf(w - size, 1)).toFloat()
                    translationY = -size * 2f
                }
                layer.addView(petal)

                ObjectAnimator.ofFloat(petal, View.TRANSLATION_Y, -size * 2f, h).apply {
                    duration = Random.nextLong(6000, 12000)
                    startDelay = Random.nextLong(0, 6000)
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
                ObjectAnimator.ofFloat(petal, View.ROTATION, 0f, 360f).apply {
                    duration = Random.nextLong(3000, 7000)
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            }
        }
    }
}
